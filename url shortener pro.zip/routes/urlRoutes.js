const express = require("express");
const router = express.Router();
const { nanoid } = require("nanoid");
const rateLimit = require("express-rate-limit");
const Url = require("../models/Url");
const { normalizeUrl } = require("../utils/normalize");

// Rate limit: max 30 shorten requests per 10 minutes per IP
const shortenLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false
});

// POST /shorten  { longUrl, customCode? }
router.post("/shorten", shortenLimiter, async (req, res) => {
  try {
    const baseUrl = process.env.BASE_URL;
    const length = parseInt(process.env.CODE_LENGTH || "7", 10);

    // 1) Normalize & validate
    const longUrl = normalizeUrl(req.body.longUrl);
    if (!longUrl) {
      return res.status(400).json({ message: "Invalid URL. Include domain (e.g., example.com) — protocol auto-added if missing." });
    }

    // 2) If same URL exists, return it (idempotent)
    let existing = await Url.findOne({ longUrl });
    if (existing) {
      return res.json({
        longUrl: existing.longUrl,
        code: existing.code,
        shortUrl: `${baseUrl}/${existing.code}`,
        clicks: existing.clicks,
        createdAt: existing.createdAt,
        lastAccessed: existing.lastAccessed
      });
    }

    // 3) If custom alias requested, ensure it's available
    let code = req.body.customCode;
    if (code) {
      code = String(code).trim();
      // basic sanity: only letters, numbers, - _ allowed
      if (!/^[a-zA-Z0-9_-]{3,30}$/.test(code)) {
        return res.status(400).json({ message: "customCode must be 3–30 chars: letters, numbers, - and _ only." });
      }
      const taken = await Url.findOne({ code });
      if (taken) {
        return res.status(409).json({ message: "That custom alias is already taken." });
      }
    } else {
      // 4) Generate random code; avoid rare collisions
      let unique = false;
      while (!unique) {
        const candidate = nanoid(length);
        const exists = await Url.exists({ code: candidate });
        if (!exists) {
          code = candidate;
          unique = true;
        }
      }
    }

    // 5) Save
    const doc = await Url.create({ code, longUrl });
    return res.status(201).json({
      longUrl: doc.longUrl,
      code: doc.code,
      shortUrl: `${baseUrl}/${doc.code}`,
      clicks: doc.clicks,
      createdAt: doc.createdAt
    });

  } catch (err) {
    console.error("Shorten error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// GET /:code  -> redirect
router.get("/:code", async (req, res) => {
  try {
    const { code } = req.params;
    const doc = await Url.findOne({ code });
    if (!doc) return res.status(404).json({ message: "No URL found" });

    // Update analytics
    doc.clicks += 1;
    doc.lastAccessed = new Date();
    await doc.save();

    // Redirect
    return res.redirect(doc.longUrl);
  } catch (err) {
    console.error("Redirect error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
