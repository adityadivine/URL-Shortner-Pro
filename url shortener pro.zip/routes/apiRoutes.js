const express = require("express");
const router = express.Router();
const Url = require("../models/Url");

// GET /api/stats/:code -> return analytics for a short code
router.get("/stats/:code", async (req, res) => {
  try {
    const { code } = req.params;
    const doc = await Url.findOne({ code });
    if (!doc) return res.status(404).json({ message: "No URL found" });

    return res.json({
      longUrl: doc.longUrl,
      code: doc.code,
      clicks: doc.clicks,
      createdAt: doc.createdAt,
      lastAccessed: doc.lastAccessed,
      shortUrl: `${process.env.BASE_URL}/${doc.code}`
    });
  } catch (err) {
    console.error("Stats error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
