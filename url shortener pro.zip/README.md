# URL Shortener Pro (Express + MongoDB + React Client)

A compact URL shortener with **custom aliases**, **analytics**, **validation/normalization**, and **rate limiting**, plus a minimal **React client**.

## Server
- `POST /shorten` -> `{ longUrl, customCode? }`
- `GET /:code` -> redirect to long URL
- `GET /api/stats/:code` -> JSON stats

### Server Run
```
npm install
npm start
```

## Client
Located in `/client` (Vite + React).

### Client Run
```
cd client
npm install
npm run dev
```
Open the printed localhost URL (usually http://localhost:5173). Ensure server is running on 5000.
