const { isURL } = require("validator");

function normalizeUrl(input) {
  if (!input) return null;
  let url = String(input).trim();

  // If protocol missing, default to https
  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url;
  }

  // Validate
  const valid = isURL(url, {
    protocols: ["http","https"],
    require_protocol: true
  });
  return valid ? url : null;
}

module.exports = { normalizeUrl };
