import React, { useState } from 'react'

const API_BASE = 'http://localhost:5000'

export default function App() {
  const [longUrl, setLongUrl] = useState('https://leetcode.com/u/adityadivinepc')
  const [customCode, setCustomCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')

  async function shorten(e) {
    e.preventDefault()
    setLoading(true); setError(''); setResult(null)
    try {
      const res = await fetch(`${API_BASE}/shorten`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ longUrl, customCode: customCode || undefined })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message || 'Failed to shorten')
      setResult(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  async function fetchStats() {
    if (!result?.code) return
    try {
      const res = await fetch(`${API_BASE}/api/stats/${result.code}`)
      const data = await res.json()
      if (res.ok) setResult({ ...result, ...data })
    } catch (err) {
      // ignore
    }
  }

  function copyToClipboard(text) {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="container">
      <h1>URL Shortener Pro</h1>
      <p className="muted">Paste a long link, optionally set a custom alias, and get a short URL you can share.</p>
      <form onSubmit={shorten}>
        <input
          type="text"
          placeholder="Enter long URL (e.g., leetcode.com/u/adityadivinepc)"
          value={longUrl}
          onChange={e => setLongUrl(e.target.value)}
        />
        <button disabled={loading}>{loading ? 'Shortening...' : 'Shorten'}</button>
      </form>
      <div className="row">
        <input
          type="text"
          placeholder="Custom alias (optional, 3–30 chars)"
          value={customCode}
          onChange={e => setCustomCode(e.target.value)}
        />
        <button type="button" onClick={() => { setCustomCode('aditya') }}>Try “aditya”</button>
      </div>

      {error && <div className="error">{error}</div>}

      {result && (
        <div className="result">
          <a className="short" href={result.shortUrl} target="_blank" rel="noreferrer">{result.shortUrl}</a>
          <div>
            <button type="button" onClick={() => copyToClipboard(result.shortUrl)}>Copy</button>
          </div>
        </div>
      )}

      {result?.code && (
        <div className="stats">
          <button type="button" onClick={fetchStats}>Refresh stats</button>
          <div>Clicks: <strong>{result.clicks ?? 0}</strong></div>
          {result.lastAccessed && <div>Last accessed: {new Date(result.lastAccessed).toLocaleString()}</div>}
        </div>
      )}
    </div>
  )
}
